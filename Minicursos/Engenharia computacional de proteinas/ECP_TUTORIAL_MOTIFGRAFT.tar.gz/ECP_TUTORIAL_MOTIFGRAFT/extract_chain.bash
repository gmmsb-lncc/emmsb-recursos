#!/bin/bash
pdbfile=$1
chain=$2
mol=$3

if ( test $# -lt 2 ); then
	echo ""
        echo "***ERROR(1): Please, provide a valid pdb file and chain ID."
        echo "             Type: extract_chain <pdbfile> <chain ID> protein"
        echo "             Flag \"protein\" is optional for retrieving only protein atoms."
        echo ""
        exit 1
elif ( test $# -gt 3 ); then
	echo ""
        echo "***ERROR(2): Too many arguments in command line."
        echo "             Type: extract_chain <pdbfile> <chain ID> protein"
        echo "             Flag \"protein\" is optional for retrieving only protein atoms."
        echo ""
        exit 2
elif [ ! -e $pdbfile ]; then
	echo ""
	echo "***ERROR(3): The file $pdbfile does not exist."
        echo "             Type: extract_chain <pdbfile> <chain ID> protein"
        echo "             Flag \"protein\" is optional for retrieving only protein atoms."
	echo ""
	exit 3
elif [[ $chain =~ ^[0-9]+$ ]] || ( test ${#chain} -gt 1 ) || [[ "$chain" =~ [^a-zA-Z] ]] ; then
	echo ""
	echo "***ERROR(4): The value $chain is not permitted for chain label."
        echo "             Type: extract_chain <pdbfile> <chain ID> protein"
        echo "             Flag \"protein\" is optional for retrieving only protein atoms."
	echo ""
	exit 4
elif [[ $mol = "protein" ]]; then
	chain=`echo $chain | tr '[:lower:]' '[:upper:]'`
	echo "REMARK "
	echo "REMARK *********************************************************************"
	echo "REMARK You have choosed chain $chain from $pdbfile and only protein atoms."
	echo "REMARK This will NOT retrieve ions nor ligands atoms from chain ${chain}."
	echo "REMARK If you wish ALL atoms, supress flag \"protein\"." 
	echo "REMARK Type: extract_chain $pdbfile $chain"
	echo "REMARK *********************************************************************"
	echo "REMARK "
	awk '/ATOM/ && $1 == "ATOM" && ($5 == "'$chain'" || $5 ~/^'$chain'/)' $pdbfile
	echo "TER"
	exit 0
elif [ -z $mol ]; then 
	chain=`echo $chain | tr '[:lower:]' '[:upper:]'`
	echo "REMARK "
	echo "REMARK ********************************************************************************"
	echo "REMARK You have choosed chain $chain from $pdbfile and all molecule atoms."
	echo "REMARK This will retrieve ions and ligands atoms from chain ${chain}."
	echo "REMARK "
	echo "REMARK WARNING: Water molecules are not retrieved!"
	echo "REAMRK "
	echo "REMARK If you wish only PROTEIN atoms, add flag \"protein\" to command line."
	echo "REMARK Type: extract_chain $pdbfile $chain protein"
	echo "REMARK ********************************************************************************"
	echo "REMARK "
	awk '($1 == "ATOM" || $1 == "HETATM") && ($5 == "'$chain'" || $5 ~/^'$chain'/) && ! ($4 == "HOH")' $pdbfile
	echo "TER"
	exit 0
else
	echo ""
        echo "***ERROR(5): The value $mol is not permitted for molecule label."
        echo "             Type: extract_chain <pdbfile> <chain ID> protein"
        echo "             Flag \"protein\" is optional for retrieving only protein atoms."
        echo ""
        exit 5

fi
