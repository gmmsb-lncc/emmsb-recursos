#!/bin/bash

for dir in `ls ./outputs_pbee`; do

   energy=$(cat ./outputs_pbee/$dir/dG_pred.csv | awk -F',' '{print $2}')

   echo $dir $energy

done
