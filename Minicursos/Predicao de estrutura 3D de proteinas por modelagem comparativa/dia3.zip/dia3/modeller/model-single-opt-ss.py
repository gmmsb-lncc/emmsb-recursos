# Homology modeling by the automodel class
#
# Demonstrates how to build multi-chain models
from modeller import *
from modeller.automodel import *    # Load the automodel class

log.verbose()
env = environ()

#Considering heteroatoms and waters molecules
env.io.hetatm = env.io.water = True
# Directories with input atom files:
#env.io.atom_files_directory = './:../atom_files'
env.io.atom_files_directory = ['./', '../atom_files']


# Override the 'special_restraints' and 'user_after_single_model' methods:
class MyModel(automodel):
    def special_restraints(self, aln):
   
        rsr = self.restraints
        at = self.atoms

             
        #rsr.add(forms.gaussian(group=physical.xy_distance,
         #                    feature=features.distance(at['CB:44:A'],at['CB:58:A']),
          #                   mean=11.0, stdev=0.5))
        
        #rsr.add(secondary_structure.strand(self.residue_range('X:A', 'Y:A'))) 
      

#      An anti-parallel sheet composed of the two strands:
       # rsr.add(secondary_structure.sheet(at['N:1:A'], at['O:2:A'], 
        #                                  sheet_h_bonds=-11))
        #rsr.add(secondary_structure.sheet(at['N:3:A'], at['O:4:A'],
         #                                 sheet_h_bonds=-11))



        rsr.add(secondary_structure.alpha(self.residue_range('7:A', '29:A')))
        rsr.add(secondary_structure.alpha(self.residue_range('31:A', '49:A')))

     

        #def user_after_single_model(self):
        # Report on symmetry violations greater than 1A after building
        # each model:
        #self.restraints.symmetry.report(1.0)

# Be sure to use 'MyModel' rather than 'automodel' here!



a = MyModel(env,
             alnfile='alvo.ali',
              knowns =('./5lsa', './4pyi'),
              sequence='alvo',
              assess_methods=(assess.DOPE, assess.normalized_dope, assess.GA341)

	    )

a.starting_model= 1                # index of the first model
a.ending_model  = 10                # index of the last model
                                   # (determines how many models to calculate)

###################################################################################
##FROM: http://salilab.org/modeller/manual/node19.html
##See Section A.4 for a detailed description of the optimization and refinement protocol used by automodel. To summarize, each model is first optimized with the variable target function method  (VTFM) with conjugate gradients (CG), and is then refined using molecular dynamics (MD) with simulated annealing (SA) [S ali & Blundell, 1993]. Most of the time (70%) is spent on the MD&SA part. Our experience is that when MD&SA are used, if there are violations in the best of the 10 models, they probably come from an alignment error, not an optimizer failure (if there are no insertions longer than approximately 15 residues).
##The VTFM step can be tuned by adjusting automodel.library_schedule, automodel.max_var_iterations, and automodel.max_molpdf.
##The MD&SA step can be tuned by adjusting automodel.md_level.
##The whole optimization can be repeated multiple times if desired (by default it is run only once) by adjusting automodel.repeat_optimization.
##The energy function used in both VTFM and MD&SA can be scaled by setting environ.schedule_scale. (Note that for VTFM, the function is additionally scaled by the factors set in automodel.library_schedule.)
###################################################################################
# Very thorough Variable Target Function Method (VTFM) optimization:
a.library_schedule = autosched.slow
a.max_var_iterations = 300

# Thorough MD optimization:
a.md_level = refine.slow

# Repeat the whole cycle 2 times and do not stop unless obj.func. > 1E6
a.repeat_optimization = 5
a.max_molpdf = 1e6
###################################################################################

a.make()                           # do homology modeling

# Get clusters
a.cluster(cluster_cut=1.00)
# END OF MODEL CONSTRUCTION


# PRINT RESULTS
# Open a file
fo = open("model-single-opt.out", "w")

# Get a list of all successfully built models from a.outputs
ok_models = filter(lambda x: x['failure'] is None, a.outputs)

# Printing out a summary of all successfully generated models
print >> fo, '\n>> Summary of successfully produced model'
fields = [x for x in ok_models[0].keys() if x.endswith(' score')]
fields.sort()
fields = ['molpdf'] + fields
header = '%-25s ' % 'Filename' + " ".join(['%14s' % x for x in fields])
print >> fo, header
print >> fo, '-' * len(header)
for mdl in ok_models:
    text = '%-25s' % mdl['name']
    for field in fields:
	if isinstance(mdl[field], (tuple, list)):
	    text = text + ' %14.5f' % mdl[field][0]
	else:
	    text = text + ' %14.5f' % mdl[field]
    print >> fo, text
print >> fo, ''

# Printing top model results
print >> fo, '>> Top model results:'
  
# Rank models by molpdf score
key = 'molpdf'
ok_models.sort(lambda a,b: cmp(a[key], b[key]))
# Get top model - molpdf
m = ok_models[0]
print "Top model_molpdf: %s (molpdf %.3f)" % (m['name'], m[key])
print >> fo, 'molpdf: ', m[key], '(file: ', m['name'], ')'

# Rank models by DOPE score
key = 'DOPE score'
ok_models.sort(lambda a,b: cmp(a[key], b[key]))
# Get top model - DOPE
m = ok_models[0]
print "Top model_DOPE: %s (DOPE score %.3f)" % (m['name'], m[key])
print >> fo, 'DOPE score: ', m[key], '(file: ', m['name'], ')'

# Rank models by normalized DOPE score
key = 'GA341 score'
ok_models.sort(lambda a,b: cmp(a[key], b[key]))
# Get top model - normalized DOPE
m = ok_models[0]
print "Top model_GA341: %s (GA341 score %.3f)" % (m['name'], m[key][0])
print >> fo, 'GA341 score: ', m[key][0], '(file: ', m['name'], ')'

# Rank models by normalized DOPE score
key = 'Normalized DOPE score'
ok_models.sort(lambda a,b: cmp(a[key], b[key]))
# Get top model - normalized DOPE
m = ok_models[0]
print "Top model_nDOPE (z): %s (Normalized DOPE score %.3f)" % (m['name'], m[key])
print >> fo, 'Normalized DOPE score: ', m[key], '(file: ', m['name'], ')'

# Read a model previously generated by Modeller's automodel class
mdl = complete_pdb(env, './cluster.opt')

# Select all atoms in the first chain
atmsel = selection(mdl)

score = atmsel.assess_dope()
zscore = mdl.assess_normalized_dope()
score2 = mdl.assess_ga341()

# Printing assess results
print >> fo, '\n>> Cluster results:'

fo2 = open("cluster.opt", "r")
lines = [ i.rstrip() for i in fo2.readlines()]
# 3rd line
print >> fo, lines[1], '(molpdf)'

print >> fo, 'DOPE score: ', score
print >> fo, 'GA341 score: ', score2[0]
print >> fo, 'Normalized DOPE score: ', zscore

# Close opened file
fo.close()
#END OF PRINT RESULTS