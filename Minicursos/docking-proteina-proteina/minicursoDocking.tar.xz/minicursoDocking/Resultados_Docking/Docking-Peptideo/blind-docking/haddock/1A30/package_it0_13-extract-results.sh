
tar xfz packages/package_it0_13-result.tar.gz >&/dev/null

rm -f complex_run1_it0_refine_241.out
touch complex_run1_it0_refine_241.out.gz

rm -f complex_run1_it0_refine_242.out
touch complex_run1_it0_refine_242.out.gz

rm -f complex_run1_it0_refine_243.out
touch complex_run1_it0_refine_243.out.gz

rm -f complex_run1_it0_refine_244.out
touch complex_run1_it0_refine_244.out.gz

rm -f complex_run1_it0_refine_245.out
touch complex_run1_it0_refine_245.out.gz

rm -f complex_run1_it0_refine_246.out
touch complex_run1_it0_refine_246.out.gz

rm -f complex_run1_it0_refine_247.out
touch complex_run1_it0_refine_247.out.gz

rm -f complex_run1_it0_refine_248.out
touch complex_run1_it0_refine_248.out.gz

rm -f complex_run1_it0_refine_249.out
touch complex_run1_it0_refine_249.out.gz

rm -f complex_run1_it0_refine_250.out
touch complex_run1_it0_refine_250.out.gz

rm -f complex_run1_it0_refine_251.out
touch complex_run1_it0_refine_251.out.gz

rm -f complex_run1_it0_refine_252.out
touch complex_run1_it0_refine_252.out.gz

rm -f complex_run1_it0_refine_253.out
touch complex_run1_it0_refine_253.out.gz

rm -f complex_run1_it0_refine_254.out
touch complex_run1_it0_refine_254.out.gz

rm -f complex_run1_it0_refine_255.out
touch complex_run1_it0_refine_255.out.gz

rm -f complex_run1_it0_refine_256.out
touch complex_run1_it0_refine_256.out.gz

rm -f complex_run1_it0_refine_257.out
touch complex_run1_it0_refine_257.out.gz

rm -f complex_run1_it0_refine_258.out
touch complex_run1_it0_refine_258.out.gz

rm -f complex_run1_it0_refine_259.out
touch complex_run1_it0_refine_259.out.gz

rm -f complex_run1_it0_refine_260.out
touch complex_run1_it0_refine_260.out.gz
