
tar xfz packages/package_it1_7-result.tar.gz >&/dev/null

rm -f complex_run1_it1_refine_31.out
touch complex_run1_it1_refine_31.out.gz

rm -f complex_run1_it1_refine_32.out
touch complex_run1_it1_refine_32.out.gz

rm -f complex_run1_it1_refine_33.out
touch complex_run1_it1_refine_33.out.gz

rm -f complex_run1_it1_refine_34.out
touch complex_run1_it1_refine_34.out.gz

rm -f complex_run1_it1_refine_35.out
touch complex_run1_it1_refine_35.out.gz
