
tar xfz packages/package_it0_71-result.tar.gz >&/dev/null

rm -f complex_run1_it0_refine_1401.out
touch complex_run1_it0_refine_1401.out.gz

rm -f complex_run1_it0_refine_1402.out
touch complex_run1_it0_refine_1402.out.gz

rm -f complex_run1_it0_refine_1403.out
touch complex_run1_it0_refine_1403.out.gz

rm -f complex_run1_it0_refine_1404.out
touch complex_run1_it0_refine_1404.out.gz

rm -f complex_run1_it0_refine_1405.out
touch complex_run1_it0_refine_1405.out.gz

rm -f complex_run1_it0_refine_1406.out
touch complex_run1_it0_refine_1406.out.gz

rm -f complex_run1_it0_refine_1407.out
touch complex_run1_it0_refine_1407.out.gz

rm -f complex_run1_it0_refine_1408.out
touch complex_run1_it0_refine_1408.out.gz

rm -f complex_run1_it0_refine_1409.out
touch complex_run1_it0_refine_1409.out.gz

rm -f complex_run1_it0_refine_1410.out
touch complex_run1_it0_refine_1410.out.gz

rm -f complex_run1_it0_refine_1411.out
touch complex_run1_it0_refine_1411.out.gz

rm -f complex_run1_it0_refine_1412.out
touch complex_run1_it0_refine_1412.out.gz

rm -f complex_run1_it0_refine_1413.out
touch complex_run1_it0_refine_1413.out.gz

rm -f complex_run1_it0_refine_1414.out
touch complex_run1_it0_refine_1414.out.gz

rm -f complex_run1_it0_refine_1415.out
touch complex_run1_it0_refine_1415.out.gz

rm -f complex_run1_it0_refine_1416.out
touch complex_run1_it0_refine_1416.out.gz

rm -f complex_run1_it0_refine_1417.out
touch complex_run1_it0_refine_1417.out.gz

rm -f complex_run1_it0_refine_1418.out
touch complex_run1_it0_refine_1418.out.gz

rm -f complex_run1_it0_refine_1419.out
touch complex_run1_it0_refine_1419.out.gz

rm -f complex_run1_it0_refine_1420.out
touch complex_run1_it0_refine_1420.out.gz
