
tar xfz packages/package_it0_1-result.tar.gz >&/dev/null

rm -f complex_run1_it0_refine_2381.out
touch complex_run1_it0_refine_2381.out.gz

rm -f complex_run1_it0_refine_2382.out
touch complex_run1_it0_refine_2382.out.gz

rm -f complex_run1_it0_refine_2383.out
touch complex_run1_it0_refine_2383.out.gz

rm -f complex_run1_it0_refine_2384.out
touch complex_run1_it0_refine_2384.out.gz

rm -f complex_run1_it0_refine_2385.out
touch complex_run1_it0_refine_2385.out.gz

rm -f complex_run1_it0_refine_2386.out
touch complex_run1_it0_refine_2386.out.gz

rm -f complex_run1_it0_refine_2387.out
touch complex_run1_it0_refine_2387.out.gz

rm -f complex_run1_it0_refine_2388.out
touch complex_run1_it0_refine_2388.out.gz

rm -f complex_run1_it0_refine_2389.out
touch complex_run1_it0_refine_2389.out.gz

rm -f complex_run1_it0_refine_2390.out
touch complex_run1_it0_refine_2390.out.gz

rm -f complex_run1_it0_refine_2391.out
touch complex_run1_it0_refine_2391.out.gz

rm -f complex_run1_it0_refine_2392.out
touch complex_run1_it0_refine_2392.out.gz

rm -f complex_run1_it0_refine_2393.out
touch complex_run1_it0_refine_2393.out.gz

rm -f complex_run1_it0_refine_2394.out
touch complex_run1_it0_refine_2394.out.gz

rm -f complex_run1_it0_refine_2395.out
touch complex_run1_it0_refine_2395.out.gz

rm -f complex_run1_it0_refine_2396.out
touch complex_run1_it0_refine_2396.out.gz

rm -f complex_run1_it0_refine_2397.out
touch complex_run1_it0_refine_2397.out.gz

rm -f complex_run1_it0_refine_2398.out
touch complex_run1_it0_refine_2398.out.gz

rm -f complex_run1_it0_refine_2399.out
touch complex_run1_it0_refine_2399.out.gz

rm -f complex_run1_it0_refine_2400.out
touch complex_run1_it0_refine_2400.out.gz
